FILE(REMOVE
"CMakeFiles/CMakeRelink.dir/libtwaindsm.a"
"CMakeFiles/CMakeRelink.dir/libtwaindsm.so.2.5.0"
"CMakeFiles/CMakeRelink.dir/libtwaindsm.so.2"
"CMakeFiles/CMakeRelink.dir/libtwaindsm.so"
)
