# The set of files whose dependency integrity should be checked:
SET(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
SET(CMAKE_DEPENDS_CHECK_CXX
  "/home/host/dsm25/twain-dsm/TWAIN_DSM/src/dsm.cpp"
  "/home/host/dsm25/twain-dsm/TWAIN_DSM/src/CMakeFiles/twaindsm.dir/dsm.o"
  "/home/host/dsm25/twain-dsm/TWAIN_DSM/src/apps.cpp"
  "/home/host/dsm25/twain-dsm/TWAIN_DSM/src/CMakeFiles/twaindsm.dir/apps.o"
  "/home/host/dsm25/twain-dsm/TWAIN_DSM/src/log.cpp"
  "/home/host/dsm25/twain-dsm/TWAIN_DSM/src/CMakeFiles/twaindsm.dir/log.o"
  )
