# Empty dependencies file for twaindsm.
# This may be replaced when dependencies are built.
