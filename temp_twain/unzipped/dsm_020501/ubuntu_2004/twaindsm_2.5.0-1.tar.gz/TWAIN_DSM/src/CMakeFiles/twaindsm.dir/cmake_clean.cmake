file(REMOVE_RECURSE
  "CMakeFiles/twaindsm.dir/apps.o"
  "CMakeFiles/twaindsm.dir/dsm.o"
  "CMakeFiles/twaindsm.dir/log.o"
  "libtwaindsm.pdb"
  "libtwaindsm.so"
  "libtwaindsm.so.2"
  "libtwaindsm.so.2.5.0"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/twaindsm.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
